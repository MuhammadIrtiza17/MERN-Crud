import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Link } from 'react-router-dom';
function Update() {
  const idd = useParams();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [id, setId] = useState('');

  useEffect(() => {
    axios.get(`http://localhost:3000/getUser/${idd.id}`)
      .then(result => {
        console.log(result);
        const userData = result.data;
        setName(userData.name);
        setEmail(userData.email);
        setId(userData.id);
      })
      .catch(err => console.log(err));
  }, [idd.id]);

 const navigate = useNavigate()

 const handleUpdate = (e) =>{
  e.preventDefault()
  console.log(idd.id)
  axios.put(`http://localhost:3000/UpdateUser/${idd.id}`,{name,email,id})
 .then(res => {
  console.log(res)
  navigate('/')
 })
 .catch(err => console.log(err))
 
 
  
 }

  return (
    <>
      <Link to='/' className='btn btn-primary mb-4 floatbtn' > Data</Link>
      <div id='area'>

        <div className="container h-100 formarea">

          <form className="mx-1 mx-md-4" id="insertform" onSubmit={handleUpdate}>
            <div className="d-flex flex-row align-items-center mb-4">
              <i className="fas fa-envelope fa-lg me-3 fa-fw"></i>
              <div className="form-outline flex-fill mb-0">
                <input type="text" id="form3Example1c" className="form-control" placeholder='Enter your name' value={name} onChange={(e) => setName(e.target.value)} />
              </div>
            </div>
            <div className="d-flex flex-row align-items-center mb-4">
              <i className="fas fa-envelope fa-lg me-3 fa-fw"></i>
              <div className="form-outline flex-fill mb-0">
                <input type="email" id="form3Example3c" placeholder='Enter your email' className="form-control" value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>
            </div>
            <div className="d-flex flex-row align-items-center mb-4">
              <i className="fas fa-key fa-lg me-3 fa-fw"></i>
              <div className="form-outline flex-fill mb-0">
                <input type="number" id="form3Example4cd" placeholder='Enter your employee ID' className="form-control" value={id} onChange={(e) => setId(e.target.value)} />
              </div>
            </div>
            <div className="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
              <button type="submit" id='add' className="btn btn-primary btn-lg">UPDATE</button>
            </div>
          </form>
        </div>

      </div>
    </>

  );
}

export default Update;