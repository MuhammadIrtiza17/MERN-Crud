import React, { useState, useEffect } from 'react';
import './index.css';
import { Link } from 'react-router-dom';
import axios from 'axios';


function DataTable() {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);











  const handledelete = (id)=>{
      axios.delete(' http://localhost:3000/delete/'+id)
      .then(res => {console.log(res)
       window.location.reload()})
      .catch(err => console.log(err ))
  }



  const fetchData = async () => 
  {
    try
    {
      const response = await fetch('http://localhost:3000/data');
      if (!response.ok) {
        throw new Error('Failed to fetch data');
      }
      const jsonData = await response.json();
      setData(jsonData);
    }
    catch (error)
   {
      console.error('Error fetching data:', error);
   }
 
  };




  return (
  <div className='w-100 bg-light body'> 
   <div className='bg-light w-50 form' >
  <center><h1>EMPLOYEE DATA INFO</h1></center>
  
  <Link to='/create' className='btn btn-primary mb-4 floatbtn'>New user</Link>
  <table className="table table-light table-striped">
    <thead>
      <tr>
      <th>Id</th>
        <th>Name</th>
        <th>Email</th>
        <th>delete</th>
        <th>update</th>
      </tr>
    </thead>

    <tbody>
      {data.map((item, index) => (
        <tr key={index}>
          <td>{item.id}</td>
          <td>{item.name}</td>
          <td>{item.email}</td>
          <td>
            <button className='btn btn-outline-danger' onClick={(e) => handledelete(item.id)}> DELETE </button>
           </td>
          <td><Link to={`/update/${item._id}`} className='btn btn-outline-warning' >Update</Link></td>

        </tr>
      ))}
     
    </tbody>

  </table>
</div></div>
 
  );
}

export default DataTable;
