import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

function DataTable() {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await fetch('http://localhost:3000/data');
      if (!response.ok) {
        throw new Error('Failed to fetch data');
      }
      const jsonData = await response.json();
      setData(jsonData);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const navigate = useNavigate()
 const handleUpdate = (e) =>{
  e.preventDefault()
  axios.put('http://localhost:3001/update'+id),{name,email,id}
 .then(res => {
  console.log(res)
  navigate('/')
 }).catch(err => console.log(err))}
  return (
    <div className='bg-warning'>
      <center><h1>EMPLOYEE DATA INFO</h1></center>
      
      <table className="table table-warning table-striped">
        <thead>
          <tr>
          <th>Id</th>
            <th>Name</th>
            <th>Email</th>
            {/* Add more table headers if needed */}
          </tr>
        </thead>
        <tbody>
          {data.map((item, index) => (
            <tr key={index}>
              <td>{item.id}</td>
              <td>{item.name}</td>
              <td>{item.email}</td>
          
              {/* Add more table cells if needed */}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default DataTable;
