import React from 'react'
import ReactDOM from 'react-dom/client'
import DataTable from './getdat.jsx'
import InsertForm from './insert.jsx'
import Update from './upadte.jsx'
import { BrowserRouter, Link, Route, Router, Routes } from 'react-router-dom'

ReactDOM.createRoot(document.getElementById('root')).render(
  <BrowserRouter>
        <Routes>
        <Route path='/' element={<DataTable/>}/>
        <Route path='/create' element={<InsertForm/>}/>  
        <Route path='/update/:id' element={<Update/>}/>  
        </Routes>
  </BrowserRouter>
)
