import React from 'react'

const nav = () => {
  return (
    <div>
        <Router>
            <Route>
                <Link></Link>
                <Link></Link>
                <Link></Link>
                <Link></Link>
            </Route>
        </Router>
    </div>
  )
}

export default nav
  