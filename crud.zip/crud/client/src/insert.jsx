import React, { useState } from 'react';
import axios from 'axios';
import './index.css'
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';


function InsertForm() {

 
  const [name, setName] = useState()
  const [email, setEmail] = useState()
  const [id, setid] = useState()
  const navigate = useNavigate()
  
  const Submit = (e) => {
      e.preventDefault();
      axios.post("http://localhost:3000/post",{name,email,id})
        .then(result => {
          console.log(result)
          navigate('/')
        })
        .catch(err => console.log(err))
    }
  
  return (

    <div id='area'>
      <Link to='/' className='btn btn-primary mb-4 floatbtn' > Data</Link>

      <div className="container h-100 formarea">

        <form className="mx-1 mx-md-4" id="insertform" onSubmit={Submit}>

       <h1>INSERT INFORMATION</h1>
        <div className="d-flex flex-row align-items-center mb-4">
            <i className="fas fa-envelope fa-lg me-3 fa-fw"></i>
            <div className="form-outline flex-fill mb-0">
          <input type="text" id="form3Example1c" className="form-control" placeholder='enter your name'
            onChange={(e) => setName(e.target.value)} />

            </div>
          </div>
          <div className="d-flex flex-row align-items-center mb-4">
            <i className="fas fa-envelope fa-lg me-3 fa-fw"></i>
            <div className="form-outline flex-fill mb-0">
              <input type="email" id="form3Example3c" placeholder='enter you email' className="form-control" onChange={(e) => setEmail(e.target.value)} />
            </div>
          </div>


          <div className="d-flex flex-row align-items-center mb-4">
            <i className="fas fa-key fa-lg me-3 fa-fw"></i>
            <div className="form-outline flex-fill mb-0">
              <input type="number" id="form3Example4cd" placeholder='enter your employee id' className="form-control" onChange={(e) => setid(e.target.value)} />
            </div>
          </div>



          <div className="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
            <button type="submit" id='add' className="btn btn-primary btn-lg">ADD</button>
          </div>

        </form>

      </div>


    </div>



  );
}

export default InsertForm;
